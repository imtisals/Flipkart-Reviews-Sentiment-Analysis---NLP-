# Sentiment-Analysis-of-Flipkart-reviews-using-NLP
Scrapping reviews of a product from the Flipkart website using BeautifulSoup and performing Sentiment Analysis using NLP
